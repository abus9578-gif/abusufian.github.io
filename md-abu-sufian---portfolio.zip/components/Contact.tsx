
import React from 'react';
import { Mail, MapPin, Send, MessageCircle, Github, Linkedin, ArrowRight } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-24 lg:py-32 bg-slate-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-[4rem] shadow-2xl overflow-hidden flex flex-col lg:flex-row border border-slate-100">
          {/* Info Sidebar */}
          <div className="lg:w-2/5 bg-slate-900 p-12 lg:p-20 text-white relative">
            <div className="relative z-10 h-full flex flex-col">
              <h2 className="text-4xl lg:text-5xl font-black mb-8 leading-tight">Let's build something <span className="text-emerald-400">extraordinary</span></h2>
              <p className="text-slate-400 text-lg font-medium mb-16 leading-relaxed">
                Whether you need a simple scraper or a full-scale lead generation engine, I'm here to architect your success.
              </p>

              <div className="space-y-10 mb-20">
                <div className="flex items-start group cursor-pointer">
                  <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center mr-6 border border-white/10 group-hover:bg-emerald-500 group-hover:border-emerald-500 transition-all duration-300">
                    <Mail className="text-emerald-400 group-hover:text-white" size={24} />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase tracking-[0.2em] font-black mb-1">Direct Email</p>
                    <p className="text-xl font-bold">abus9578@gmail.com</p>
                  </div>
                </div>

                <div className="flex items-start group cursor-pointer">
                  <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center mr-6 border border-white/10 group-hover:bg-emerald-500 group-hover:border-emerald-500 transition-all duration-300">
                    <MessageCircle className="text-emerald-400 group-hover:text-white" size={24} />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase tracking-[0.2em] font-black mb-1">WhatsApp</p>
                    <p className="text-xl font-bold">01785705698</p>
                  </div>
                </div>
              </div>

              <div className="mt-auto flex items-center justify-between pt-12 border-t border-white/5">
                <div className="flex space-x-4">
                  <a href="#" className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-emerald-500 transition-all"><Github size={20}/></a>
                  <a href="#" className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-emerald-500 transition-all"><Linkedin size={20}/></a>
                </div>
                <div className="text-xs font-black uppercase tracking-widest text-slate-500">Available Globally</div>
              </div>
            </div>
            
            {/* Background Accent */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 blur-[100px] -z-0"></div>
          </div>

          {/* Form Area */}
          <div className="lg:w-3/5 p-12 lg:p-20">
            <div className="mb-12">
               <h3 className="text-3xl font-black text-slate-900 mb-4 tracking-tight">Project Inquiry</h3>
               <p className="text-slate-500 font-medium">Briefly describe your requirements and I'll get back to you within 24 hours.</p>
            </div>
            
            <form className="space-y-8" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
                  <input
                    type="text"
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-[1.5rem] px-6 py-4 focus:ring-0 focus:border-emerald-500 focus:bg-white transition-all font-bold text-slate-900 outline-none"
                    placeholder="John Doe"
                  />
                </div>
                <div className="space-y-3">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Company</label>
                  <input
                    type="text"
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-[1.5rem] px-6 py-4 focus:ring-0 focus:border-emerald-500 focus:bg-white transition-all font-bold text-slate-900 outline-none"
                    placeholder="Acme Corp"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Service Required</label>
                <select className="w-full bg-slate-50 border-2 border-slate-100 rounded-[1.5rem] px-6 py-4 focus:ring-0 focus:border-emerald-500 focus:bg-white transition-all font-bold text-slate-900 outline-none appearance-none cursor-pointer">
                  <option>Web Scraping & Data Extraction</option>
                  <option>B2B Lead Generation</option>
                  <option>Workflow Automation</option>
                  <option>Data Analytics Dashboard</option>
                </select>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Message Detail</label>
                <textarea
                  rows={5}
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-[2rem] px-6 py-4 focus:ring-0 focus:border-emerald-500 focus:bg-white transition-all font-bold text-slate-900 outline-none resize-none"
                  placeholder="Tell me about your project goals..."
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full sm:w-auto px-12 py-5 bg-slate-900 text-white rounded-[2rem] font-black hover:bg-emerald-600 transition-all flex items-center justify-center shadow-2xl hover:-translate-y-1 active:scale-95 group"
              >
                Launch Project Inquiry
                <Send size={18} className="ml-3 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </button>
            </form>
          </div>
        </div>
        
        {/* Quick Contact Bar */}
        <div className="mt-16 flex flex-wrap justify-center gap-4 sm:gap-12">
          <a href="https://wa.me/8801785705698" className="flex items-center text-slate-500 hover:text-emerald-600 font-bold transition-colors group">
            <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mr-2 group-hover:scale-110 transition-transform">
              <MessageCircle size={14} />
            </div>
            WhatsApp: 01785705698
          </a>
          <a href="mailto:abus9578@gmail.com" className="flex items-center text-slate-500 hover:text-emerald-600 font-bold transition-colors group">
            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-2 group-hover:scale-110 transition-transform">
              <Mail size={14} />
            </div>
            Email: abus9578@gmail.com
          </a>
        </div>
      </div>
    </section>
  );
};

export default Contact;
