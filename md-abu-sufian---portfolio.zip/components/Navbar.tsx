
import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowRight } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Services', href: '#services' },
    { name: 'Projects', href: '#projects' },
    { name: 'Testimonials', href: '#testimonials' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-500 ${scrolled ? 'glass-effect py-3 shadow-sm' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex-shrink-0 group">
            <a href="#home" className="text-2xl font-black tracking-tight text-slate-900 flex items-center">
              <span className="bg-emerald-600 text-white w-10 h-10 flex items-center justify-center rounded-xl mr-2 group-hover:rotate-6 transition-transform shadow-lg shadow-emerald-200">S</span>
              <span className="hidden sm:inline">Md Abu <span className="text-emerald-600">Sufian</span></span>
              <span className="sm:hidden text-emerald-600">Sufian</span>
            </a>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-10 items-center">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-slate-600 hover:text-emerald-600 font-bold text-sm uppercase tracking-wider transition-all relative group"
              >
                {link.name}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-emerald-500 transition-all group-hover:w-full"></span>
              </a>
            ))}
            <a
              href="#contact"
              className="bg-slate-900 text-white px-7 py-3.5 rounded-2xl text-sm font-black hover:bg-emerald-600 transition-all shadow-xl hover:-translate-y-1 active:scale-95 flex items-center"
            >
              Hire Me
              <ArrowRight size={16} className="ml-2 animate-[bounce_2s_infinite_horizontal]" />
            </a>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-700 hover:text-emerald-600 p-2 transition-colors bg-white/80 rounded-xl shadow-sm border border-slate-100"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className={`md:hidden absolute top-full left-0 w-full transition-all duration-300 transform ${isOpen ? 'opacity-100 translate-y-0 visible' : 'opacity-0 -translate-y-4 invisible'}`}>
        <div className="glass-effect mx-4 mt-2 rounded-[2.5rem] shadow-2xl p-6 space-y-4 border border-emerald-50 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 blur-2xl -z-10"></div>
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={() => setIsOpen(false)}
              className="block text-slate-700 hover:text-emerald-600 font-black text-xl px-4 py-4 rounded-2xl hover:bg-emerald-50 transition-all"
            >
              {link.name}
            </a>
          ))}
          <a
            href="#contact"
            onClick={() => setIsOpen(false)}
            className="block w-full text-center bg-emerald-600 text-white px-5 py-5 rounded-[2rem] font-black text-lg shadow-xl shadow-emerald-100"
          >
            Get in Touch
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
