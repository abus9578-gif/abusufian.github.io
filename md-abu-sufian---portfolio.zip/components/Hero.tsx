
import React from 'react';
import { Mail, MessageCircle, Sparkles, Code2, ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative pt-32 pb-24 lg:pt-48 lg:pb-36 overflow-hidden">
      {/* Decorative Elements */}
      <div className="hero-blob top-[-10%] right-[-10%]"></div>
      <div className="hero-blob bottom-[-10%] left-[-5%]" style={{ animationDelay: '-5s', width: '400px', height: '400px' }}></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
          <div className="lg:w-3/5 text-center lg:text-left stagger-in">
            <div className="inline-flex items-center space-x-2 bg-emerald-50 border border-emerald-100 text-emerald-700 px-4 py-1.5 rounded-full text-sm font-bold mb-8 shadow-sm">
              <Sparkles size={16} className="text-emerald-500 animate-pulse" />
              <span>Python Automation & Lead Gen Architect</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-slate-900 mb-8 leading-[1.1]">
              Transforming <span className="gradient-text">Chaos</span> into <span className="gradient-text">Structured Data</span>
            </h1>
            
            <p className="text-lg lg:text-xl text-slate-600 mb-12 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-medium">
              Hi, I’m <span className="text-slate-900 font-bold underline decoration-emerald-400 decoration-4 underline-offset-4 font-black">Md Abu Sufian</span>. I build elite Python systems that harvest insights, automate outreach, and liberate your team from manual drudgery.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 mb-16">
              <a
                href="#contact"
                className="group flex items-center justify-center w-full sm:w-auto px-10 py-5 bg-slate-900 text-white rounded-2xl font-bold hover:bg-emerald-600 transition-all duration-300 shadow-xl hover:-translate-y-1 active:scale-95"
              >
                <Mail className="mr-3 group-hover:rotate-12 transition-transform" size={20} />
                Start a Project
              </a>
              <a
                href="https://wa.me/8801785705698"
                className="flex items-center justify-center w-full sm:w-auto px-10 py-5 bg-white text-emerald-600 border-2 border-emerald-100 rounded-2xl font-bold hover:border-emerald-500 hover:bg-emerald-50 transition-all duration-300 shadow-sm hover:-translate-y-1 active:scale-95"
              >
                <MessageCircle className="mr-3 text-emerald-500" size={20} />
                WhatsApp Me
              </a>
            </div>

            <div className="grid grid-cols-3 gap-8 pt-8 border-t border-slate-200">
              <div>
                <p className="text-3xl font-extrabold text-slate-900">500+</p>
                <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Leads/Week</p>
              </div>
              <div>
                <p className="text-3xl font-extrabold text-slate-900">100%</p>
                <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Accuracy</p>
              </div>
              <div>
                <p className="text-3xl font-extrabold text-slate-900">24/7</p>
                <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Uptime</p>
              </div>
            </div>
          </div>

          <div className="lg:w-2/5 w-full stagger-in flex justify-center" style={{ animationDelay: '0.2s' }}>
            <div className="relative w-full max-w-md">
              {/* Abstract Code UI with floating animation */}
              <div className="bg-slate-900 rounded-[2.5rem] p-1 shadow-2xl overflow-hidden border-8 border-slate-800 transform lg:rotate-3 transition-transform duration-700 animate-[bounce_5s_infinite_ease-in-out]">
                <div className="bg-slate-800/50 px-6 py-4 flex items-center justify-between">
                  <div className="flex space-x-2">
                    <div className="w-3 h-3 rounded-full bg-red-400"></div>
                    <div className="w-3 h-3 rounded-full bg-amber-400"></div>
                    <div className="w-3 h-3 rounded-full bg-emerald-400"></div>
                  </div>
                  <div className="text-slate-400 text-xs font-mono">lead_gen_master.py</div>
                  <Code2 size={14} className="text-slate-500" />
                </div>
                <div className="p-8 font-mono text-sm leading-relaxed overflow-hidden bg-gradient-to-br from-slate-900 to-slate-950">
                  <div className="text-emerald-400 flex">
                    <span className="text-pink-500 mr-2">import</span>
                    <span>pandas, scrapy, logging</span>
                  </div>
                  <div className="text-slate-400 mt-2 italic"># Initializing AI Engine</div>
                  <div className="mt-4">
                    <span className="text-yellow-400">class</span> <span className="text-blue-400">SufianAutomation</span>:
                  </div>
                  <div className="ml-4 mt-2">
                    <span className="text-yellow-400">async def</span> <span className="text-blue-400">extract</span>(self, target):
                  </div>
                  <div className="ml-8 text-slate-300">
                    raw_data = <span className="text-pink-500">await</span> target.scrape()
                  </div>
                  <div className="ml-8 text-slate-300">
                    leads = self.validate(raw_data)
                  </div>
                  <div className="ml-8 text-emerald-300">
                    <span className="text-pink-500">return</span> leads.to_excel(<span className="text-amber-200">'ROI.xlsx'</span>)
                  </div>
                  
                  {/* Floating Result Badge */}
                  <div className="absolute bottom-10 right-[-10px] bg-emerald-500 text-white p-4 rounded-2xl shadow-xl transform translate-x-2">
                    <div className="text-xs font-bold uppercase opacity-80 mb-1">Status</div>
                    <div className="flex items-center space-x-2 font-bold">
                      <div className="w-2 h-2 rounded-full bg-white animate-pulse"></div>
                      <span>Extraction Active</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Background Glow */}
              <div className="absolute -inset-4 bg-emerald-500/20 rounded-[3rem] blur-2xl -z-10 animate-pulse"></div>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 animate-bounce hidden lg:block">
           <a href="#services" className="text-slate-300 hover:text-emerald-500 transition-colors">
              <ArrowDown size={32} />
           </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
