
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white py-12 border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <span className="text-2xl font-bold tracking-tight text-slate-900">
              Md Abu <span className="text-emerald-600">Sufian</span>
            </span>
            <p className="text-slate-500 mt-2 text-sm">Professional Python Automation Expert</p>
          </div>

          <div className="flex space-x-6 text-sm font-medium text-slate-500 mb-6 md:mb-0">
            <a href="#services" className="hover:text-emerald-600 transition-colors">Services</a>
            <a href="#projects" className="hover:text-emerald-600 transition-colors">Projects</a>
            <a href="#testimonials" className="hover:text-emerald-600 transition-colors">Testimonials</a>
            <a href="#contact" className="hover:text-emerald-600 transition-colors">Contact</a>
          </div>

          <div className="text-slate-400 text-sm">
            © {new Date().getFullYear()} Md Abu Sufian. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
