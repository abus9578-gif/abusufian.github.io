
import React, { useState } from 'react';
import { PROJECTS } from '../constants';
import { Project } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { CheckCircle2, ChevronRight, X, Database, Zap, ArrowUpRight } from 'lucide-react';

const ProjectCard: React.FC<{ project: Project; onClick: () => void }> = ({ project, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="bg-white rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden hover:shadow-2xl transition-all duration-500 cursor-pointer group flex flex-col h-full card-glow transform hover:-translate-y-2"
    >
      <div className="h-48 bg-slate-900 relative overflow-hidden flex items-center justify-center">
        <Database className="w-24 h-24 text-emerald-500/10 absolute rotate-12 group-hover:rotate-0 transition-transform duration-700" />
        <div className="z-10 text-center p-6">
          <div className="inline-block px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-[0.2em] rounded-full mb-3">
            {project.category}
          </div>
          <h3 className="text-xl font-bold text-white group-hover:text-emerald-400 transition-colors leading-tight">{project.name}</h3>
        </div>
        <div className="absolute top-4 right-4 bg-white/10 backdrop-blur-md rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <ArrowUpRight size={18} className="text-white" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-80"></div>
      </div>
      
      <div className="p-7 flex-grow flex flex-col">
        <div className="mb-6 flex-grow">
          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 flex items-center">
            <Zap size={10} className="mr-1 text-amber-500" />
            Core Challenge
          </h4>
          <p className="text-slate-600 text-sm font-medium leading-relaxed line-clamp-3">
            {project.problem}
          </p>
        </div>
        
        <div className="mt-auto">
          <div className="bg-emerald-50 rounded-2xl p-4 border border-emerald-100 group-hover:bg-emerald-600 group-hover:border-emerald-600 transition-colors duration-300">
            <p className="text-xs text-emerald-800 font-bold group-hover:text-white leading-tight">
               Impact: {project.result}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const ProjectModal: React.FC<{ project: Project; onClose: () => void }> = ({ project, onClose }) => {
  const COLORS = ['#10b981', '#06b6d4', '#3b82f6'];

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6 lg:p-10">
      <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-md" onClick={onClose}></div>
      <div className="relative bg-white rounded-[3rem] w-full max-w-5xl max-h-[90vh] overflow-y-auto shadow-2xl animate-in fade-in zoom-in duration-500 scrollbar-hide">
        <button
          onClick={onClose}
          className="absolute top-8 right-8 p-3 rounded-full hover:bg-slate-100 text-slate-500 transition-all hover:rotate-90 z-10 bg-white shadow-sm"
        >
          <X size={24} />
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12">
          {/* Header/Info */}
          <div className="lg:col-span-7 p-8 sm:p-12 lg:p-16">
            <div className="mb-10">
              <span className="text-emerald-600 font-black uppercase tracking-[0.3em] text-[10px] mb-3 block">{project.category}</span>
              <h2 className="text-4xl lg:text-5xl font-black text-slate-900 mb-6 leading-tight">{project.name}</h2>
              <div className="w-24 h-2 bg-emerald-600 rounded-full"></div>
            </div>

            <div className="space-y-10">
              <div className="group">
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center">
                  <span className="w-8 h-8 rounded-xl bg-slate-100 text-slate-900 flex items-center justify-center mr-3 font-mono">01</span>
                  The Problem
                </h4>
                <p className="text-slate-600 text-lg leading-relaxed pl-11 font-medium">{project.problem}</p>
              </div>

              <div className="group">
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center">
                  <span className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mr-3 font-mono">02</span>
                  The Solution
                </h4>
                <p className="text-slate-600 text-lg leading-relaxed pl-11 font-medium">{project.solution}</p>
              </div>

              <div className="bg-emerald-50 rounded-[2rem] p-8 border border-emerald-100">
                <h4 className="text-xs font-black text-emerald-600 uppercase tracking-widest mb-4 flex items-center">
                  <Zap size={16} className="mr-2" />
                  Key Outcome
                </h4>
                <p className="text-emerald-900 text-xl font-extrabold leading-tight">{project.result}</p>
              </div>
            </div>
          </div>

          {/* Visualization */}
          <div className="lg:col-span-5 bg-slate-50 p-8 sm:p-12 lg:p-16 border-l border-slate-100 flex flex-col justify-center">
            <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-8 text-center">Efficiency Analytics</h4>
            <div className="h-[300px] w-full bg-white rounded-[2rem] p-6 shadow-sm border border-slate-200/50">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={project.impactData} layout="vertical" margin={{ left: -10, right: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" width={80} axisLine={false} tickLine={false} style={{ fontSize: '12px', fontWeight: 800, fill: '#64748b' }} />
                  <Tooltip 
                    cursor={{fill: 'transparent'}} 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                  />
                  <Bar dataKey="value" radius={[0, 8, 8, 0]} barSize={30}>
                    {project.impactData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <p className="text-sm font-bold text-center text-slate-400 mt-8 leading-relaxed max-w-xs mx-auto italic">
              "Data driven approach to ensuring maximum ROI for every automation."
            </p>
            
            <div className="mt-auto pt-12 flex flex-col gap-4">
              <div className="flex items-center justify-center space-x-3 text-xs font-bold text-slate-500 uppercase tracking-widest">
                <CheckCircle2 size={16} className="text-emerald-500" />
                <span>Verified Solution</span>
              </div>
              <a
                href="https://wa.me/8801785705698"
                className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-center hover:bg-emerald-600 transition-all shadow-xl hover:-translate-y-1"
              >
                Discuss Similar Project
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ProjectGrid: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <section id="projects" className="py-24 lg:py-32 bg-slate-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-xs font-black uppercase tracking-[0.2em] mb-4">Portfolio</div>
          <h2 className="text-4xl lg:text-6xl font-black text-slate-900 mb-6 tracking-tight">Proven Results in <span className="gradient-text">Automation</span></h2>
          <p className="text-slate-500 max-w-2xl mx-auto text-lg font-medium leading-relaxed">
            I don't just write code; I build competitive advantages. Explore 12 enterprise-ready projects that solve complex data problems.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {PROJECTS.map((project, idx) => (
            <div key={project.id} className="stagger-in" style={{ animationDelay: `${idx * 0.05}s` }}>
              <ProjectCard
                project={project}
                onClick={() => setSelectedProject(project)}
              />
            </div>
          ))}
        </div>
        
        <div className="mt-20 text-center">
          <a
            href="#contact"
            className="inline-flex items-center px-8 py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-200 group"
          >
            Request a Custom Demo
            <ChevronRight className="ml-2 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default ProjectGrid;
