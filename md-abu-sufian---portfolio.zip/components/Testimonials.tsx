
import React from 'react';
import { TESTIMONIALS } from '../constants';
import { Star, Quote } from 'lucide-react';

const Testimonials: React.FC = () => {
  return (
    <section id="testimonials" className="py-24 lg:py-32 bg-white relative overflow-hidden">
      <Quote className="absolute top-10 right-10 w-64 h-64 text-slate-50 opacity-10 -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-xs font-black uppercase tracking-[0.2em] mb-4">Reviews</div>
          <h2 className="text-4xl lg:text-6xl font-black text-slate-900 mb-6 tracking-tight">What My <span className="gradient-text">Clients</span> Say</h2>
          <div className="w-20 h-2 bg-emerald-600 mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {TESTIMONIALS.map((t, index) => (
            <div
              key={index}
              className="group p-10 rounded-[2.5rem] border border-slate-100 bg-slate-50 flex flex-col justify-between hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 relative"
            >
              <Quote className="absolute top-8 left-8 w-12 h-12 text-emerald-500/10 group-hover:text-emerald-500/20 transition-colors" />
              
              <div className="relative z-10">
                <div className="flex text-amber-400 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={18} fill="currentColor" />
                  ))}
                </div>
                <p className="text-slate-700 text-lg italic leading-relaxed mb-10 font-medium">
                  "{t.content}"
                </p>
              </div>

              <div className="flex items-center mt-auto border-t border-slate-200 pt-8">
                <img
                  src={t.avatar}
                  alt={t.name}
                  className="w-14 h-14 rounded-2xl border-2 border-white shadow-sm object-cover mr-4"
                />
                <div>
                  <h4 className="font-black text-slate-900 text-sm tracking-tight">{t.name}</h4>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">{t.role} @ {t.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
