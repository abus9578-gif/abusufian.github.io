
import React from 'react';
import { SERVICES } from '../constants';
import { ArrowRight } from 'lucide-react';

const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 lg:py-32 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row justify-between items-end mb-16 gap-8">
          <div className="max-w-2xl">
            <div className="inline-block px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-xs font-black uppercase tracking-[0.2em] mb-4">Core Expertise</div>
            <h2 className="text-4xl lg:text-6xl font-black text-slate-900 leading-tight">Elite Data Solutions for <span className="gradient-text">Modern Business</span></h2>
          </div>
          <p className="text-slate-500 font-medium text-lg lg:max-w-md lg:mb-4">
            Leveraging cutting-edge Python libraries to deliver accurate, scalable, and resilient automation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {SERVICES.map((service, index) => (
            <div
              key={index}
              className="p-10 rounded-[2.5rem] border border-slate-100 bg-slate-50 hover:bg-white hover:shadow-2xl hover:-translate-y-3 transition-all duration-500 group relative overflow-hidden"
            >
              <div className="absolute -right-4 -top-4 w-24 h-24 bg-emerald-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
              
              <div className="mb-8 bg-white w-20 h-20 rounded-[1.5rem] flex items-center justify-center shadow-sm group-hover:bg-emerald-600 group-hover:shadow-emerald-200 transition-all duration-500">
                <div className="group-hover:text-white transition-colors transform group-hover:scale-110 transition-transform duration-500">
                  {service.icon}
                </div>
              </div>
              
              <h3 className="text-2xl font-black text-slate-900 mb-4 tracking-tight">{service.title}</h3>
              <p className="text-slate-500 font-medium leading-relaxed mb-8">
                {service.description}
              </p>
              
              <div className="mt-auto flex items-center text-emerald-600 font-black text-xs uppercase tracking-widest opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-500">
                Learn More <ArrowRight size={14} className="ml-2" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
